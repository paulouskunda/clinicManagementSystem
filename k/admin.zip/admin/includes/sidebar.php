<div class="container-fluid-full">
<div class="row-fluid">
		
	<!-- start: Main Menu -->
	<div id="sidebar-left" class="span2">
		<div class="nav-collapse sidebar-nav">
			<ul class="nav nav-tabs nav-stacked main-menu">
				<li><a href="index.php"><i class="icon-dashboard"></i><span class="hidden-tablet"> Dashboard</span></a></li>
				<li><a href="users.php"><i class="icon-user"></i><span class="hidden-tablet"> Active Users</span></a></li>
<!-- 				<li><a href="messages.html"><i class="icon-envelope"></i><span class="hidden-tablet"> Messages</span></a></li>
				<li><a href="tasks.html"><i class="icon-tasks"></i><span class="hidden-tablet"> Tasks</span></a></li>
				<li><a href="ui.html"><i class="icon-eye-open"></i><span class="hidden-tablet"> UI Features</span></a></li>
				<li><a href="widgets.html"><i class="icon-dashboard"></i><span class="hidden-tablet"> Widgets</span></a></li> -->
				<li>
					<a class="dropmenu" href="#"><i class="icon-reorder"></i><span class="hidden-tablet">Includes</span></a>
					<ul>
						<li><a class="submenu" href="add_new.php"><i class="icon-file-alt"></i><span class="hidden-tablet"> Add New Record</span></a></li>
						<li><a class="submenu" href="unactive.php"><i class="icon-user"></i><span class="hidden-tablet">InActive Artist</span></a></li>
						<!-- <li><a class="submenu" href="submenu3.html"><i class="icon-file-alt"></i><span class="hidden-tablet"> Sub Menu 3</span></a></li> -->
					</ul>	
				</li>
				<li><a href="logout.php"><i class="icon-off"></i><span class="hidden-tablet"> Logout</span></a></li>

			</ul>
		</div>
	</div>