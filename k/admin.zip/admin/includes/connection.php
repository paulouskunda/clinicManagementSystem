<?php

$con = mysqli_connect("localhost","root","","myweb") or
 die('Could not connect to the database!');


// mysqli_select_db($con,) or
//  die('No database selected!');
?>